﻿using Microsoft.AspNetCore.Mvc;
using PokemonMVC.Models;
using Newtonsoft.Json.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Linq;

namespace PokemonMVC.Controllers
{
    public class PokemonController : Controller
    {
        private readonly HttpClient _httpClient;

        public PokemonController()
        {
            _httpClient = new HttpClient();
            _httpClient.BaseAddress = new System.Uri("https://pokeapi.co/api/v2/");
        }

        public async Task<IActionResult> Index(int page = 1)
        {
            var response = await _httpClient.GetStringAsync($"pokemon?offset={(page - 1) * 20}&limit=20");
            var data = JObject.Parse(response);
            var pokemonList = data["results"].Select(p => p["name"].ToString()).ToList();

            ViewBag.Page = page;
            return View(pokemonList);
        }

        public async Task<IActionResult> Details(string name)
        {
            var response = await _httpClient.GetStringAsync($"pokemon/{name}");
            var data = JObject.Parse(response);
            var pokemon = new Pokemon
            {
                Name = data["name"].ToString(),
                Moves = data["moves"].Select(m => m["move"]["name"].ToString()).ToList(),
                Abilities = data["abilities"].Select(a => a["ability"]["name"].ToString()).ToList()
            };

            return View(pokemon);
        }
    }
}
